class PrintGrap{
	public static void main(String[] args){
		
		System.out.print("\t");
		System.out.print("*");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		
		System.out.println("*");

		
		System.out.print("*");
		System.out.print("\t");
		//System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("I love java");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		
		System.out.println("*");

		
		System.out.print("\t");
		System.out.print("*");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		
		System.out.println("*");

		
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("*");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		
		System.out.println("*");

		
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("*");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		
		System.out.println("*");
		
		
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("*");
		System.out.print("\t");
		
		System.out.println("*");

		
		System.out.print("\t");
		System.out.print("\t");
		System.out.print("\t");
		//System.out.print("\t");
		System.out.print("      ");
		System.out.print("*");


	}

}